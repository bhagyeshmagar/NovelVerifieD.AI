import React, { useState, useEffect } from 'react';
import {
    Search, ExternalLink, X, CheckCircle, XCircle, AlertCircle
} from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { api } from '../services/api';

const Results = () => {
    const [results, setResults] = useState([]);
    const [loading, setLoading] = useState(true);
    const [filter, setFilter] = useState('all');
    const [search, setSearch] = useState('');
    const [selectedClaim, setSelectedClaim] = useState(null);

    useEffect(() => {
        loadResults();
    }, []);

    const loadResults = async () => {
        try {
            const data = await api.getResults();
            setResults(data.results || []);
        } catch (err) {
            console.error(err);
        } finally {
            setLoading(false);
        }
    };

    const filteredResults = results.filter(r => {
        const matchesSearch = r.rationale?.toLowerCase().includes(search.toLowerCase()) ||
            r.character?.toLowerCase().includes(search.toLowerCase());
        const matchesFilter = filter === 'all' ||
            (filter === 'supported' && r.prediction === 1) ||
            (filter === 'contradicted' && r.prediction === 0);
        return matchesSearch && matchesFilter;
    });

    return (
        <div className="results-page fade-in pb-12">
            <header className="page-header">
                <h1 className="text-4xl font-black text-white mb-2 tracking-tight">Claim Results</h1>
                <p className="text-secondary text-lg">
                    {filteredResults.length} claims processed and verified
                </p>
            </header>

            {/* Toolbar */}
            <div className="toolbar glass-panel p-4 mb-8 flex flex-col md:flex-row gap-4 items-center">
                <div className="relative flex-1 w-full">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-text-muted" size={20} />
                    <input
                        type="text"
                        placeholder="Search by character or rationale keyword..."
                        className="w-full bg-bg-secondary border border-white/10 rounded-xl pl-12 pr-4 py-3 text-text-primary focus:outline-none focus:border-accent-primary focus:ring-1 focus:ring-accent-primary transition-all"
                        value={search}
                        onChange={e => setSearch(e.target.value)}
                    />
                </div>

                <div className="flex gap-2 w-full md:w-auto overflow-x-auto">
                    {['all', 'supported', 'contradicted'].map(f => (
                        <button
                            key={f}
                            onClick={() => setFilter(f)}
                            className={`px-6 py-3 rounded-xl capitalize text-sm font-bold transition-all whitespace-nowrap ${filter === f
                                    ? 'bg-accent-primary text-white shadow-lg shadow-blue-500/20'
                                    : 'bg-bg-hover text-text-secondary hover:text-white hover:bg-white/5'
                                }`}
                        >
                            {f}
                        </button>
                    ))}
                </div>
            </div>

            {/* Results Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-2 2xl:grid-cols-3 gap-6">
                {loading ? (
                    <div className="col-span-full text-center py-20 text-text-muted animate-pulse">Loading results...</div>
                ) : filteredResults.length === 0 ? (
                    <div className="col-span-full text-center py-20 text-text-muted">No results found matching your criteria</div>
                ) : (
                    filteredResults.map(claim => (
                        <ClaimCard
                            key={claim.id}
                            claim={claim}
                            onClick={setSelectedClaim}
                        />
                    ))
                )}
            </div>

            {/* Modal */}
            {selectedClaim && (
                <DetailModal
                    claim={selectedClaim}
                    onClose={() => setSelectedClaim(null)}
                />
            )}
        </div>
    );
};

const ClaimCard = ({ claim, onClick }) => (
    <div
        className="glass-panel p-6 cursor-pointer group hover:border-accent-primary/50 transition-all duration-300 hover:transform hover:-translate-y-1 relative overflow-hidden"
        onClick={() => onClick(claim)}
    >
        <div className="absolute top-0 right-0 p-4 opacity-50 font-mono text-xs text-text-muted">#{claim.id}</div>

        <div className="flex flex-col h-full">
            <div className="mb-4 pr-10">
                <div className="text-xs font-bold text-accent-primary uppercase tracking-wider mb-1">{claim.book_name}</div>
                <h3 className="font-bold text-xl text-white group-hover:text-accent-primary transition-colors">{claim.character}</h3>
            </div>

            <p className="text-text-secondary text-sm leading-relaxed line-clamp-3 mb-6 flex-1 min-h-[4.5em]">
                {claim.rationale}
            </p>

            <div className="pt-4 border-t border-white/5 flex justify-between items-end">
                <div className="flex items-center gap-3">
                    {claim.prediction === 1 ? (
                        <span className="badge success flex items-center gap-1.5 px-3 py-1.5">
                            <CheckCircle size={14} /> Supported
                        </span>
                    ) : (
                        <span className="badge danger flex items-center gap-1.5 px-3 py-1.5">
                            <XCircle size={14} /> Contradicted
                        </span>
                    )}
                </div>

                <div className="text-right">
                    <div className="text-xs text-text-muted uppercase font-bold mb-0.5">Confidence</div>
                    <div className="text-xl font-black text-white">{(claim.confidence * 100).toFixed(0)}%</div>
                </div>
            </div>

            <div className="mt-4 opacity-0 group-hover:opacity-100 transition-opacity absolute bottom-6 right-6 lg:static lg:mt-4 lg:opacity-100 lg:w-full">
                <button className="w-full btn-secondary text-sm items-center justify-center hover:bg-accent-primary hover:border-accent-primary hover:text-white group-hover:shadow-lg">
                    View Details <ExternalLink size={14} className="ml-2" />
                </button>
            </div>
        </div>
    </div>
);

const DetailModal = ({ claim, onClose }) => {
    const [dossier, setDossier] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const loadDossier = async () => {
            try {
                const data = await api.getDossier(claim.id);
                setDossier(data.content);
            } catch (err) {
                console.error(err);
            } finally {
                setLoading(false);
            }
        };
        loadDossier();

        // Lock body scroll
        document.body.style.overflow = 'hidden';
        return () => { document.body.style.overflow = 'unset'; }
    }, [claim]);

    return (
        <div
            className="fixed inset-0 z-[9999] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200"
            onClick={onClose}
        >
            <div
                className="glass-panel w-full max-w-5xl max-h-[85vh] flex flex-col shadow-2xl border-white/10"
                onClick={e => e.stopPropagation()}
                style={{ background: '#0e1015' }}
            >
                {/* Header */}
                <div className="p-6 border-b border-white/10 flex justify-between items-center bg-white/5">
                    <div>
                        <div className="text-xs font-mono text-text-muted mb-1">CLAIM ID: {claim.id}</div>
                        <h2 className="text-2xl font-bold text-white flex items-center gap-3">
                            Verification Analysis
                            {claim.prediction === 1 ? (
                                <span className="badge success ml-2">Supported</span>
                            ) : (
                                <span className="badge danger ml-2">Contradicted</span>
                            )}
                        </h2>
                    </div>
                    <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full text-text-muted hover:text-white transition-colors">
                        <X size={24} />
                    </button>
                </div>

                {/* Scrollable Content */}
                <div className="flex-1 overflow-y-auto p-8 custom-scrollbar">
                    {/* Key Info Cards */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                        <div className="bg-bg-secondary p-5 rounded-xl border border-white/5">
                            <h3 className="text-xs font-bold text-text-muted uppercase tracking-wider mb-2">Character</h3>
                            <div className="text-white font-bold text-xl">{claim.character}</div>
                        </div>
                        <div className="bg-bg-secondary p-5 rounded-xl border border-white/5">
                            <h3 className="text-xs font-bold text-text-muted uppercase tracking-wider mb-2">Book</h3>
                            <div className="text-white font-bold text-xl">{claim.book_name}</div>
                        </div>
                        <div className="bg-bg-secondary p-5 rounded-xl border border-white/5">
                            <h3 className="text-xs font-bold text-text-muted uppercase tracking-wider mb-2">Confidence</h3>
                            <div className={`text-3xl font-black ${claim.confidence > 0.8 ? 'text-accent-success' : 'text-accent-warning'}`}>
                                {(claim.confidence * 100).toFixed(1)}%
                            </div>
                        </div>
                    </div>

                    <div className="mb-10">
                        <h3 className="text-sm font-bold text-accent-primary uppercase tracking-wider mb-3 flex items-center gap-2">
                            <AlertCircle size={16} /> Reasoning Logic
                        </h3>
                        <p className="text-lg text-text-primary leading-relaxed bg-bg-secondary p-8 rounded-xl border border-white/5 shadow-inner">
                            {claim.rationale}
                        </p>
                    </div>

                    <div className="prose prose-invert max-w-none prose-headings:text-white prose-a:text-accent-primary prose-strong:text-white prose-blockquote:border-accent-primary">
                        <h3 className="text-sm font-bold text-text-muted uppercase tracking-wider mb-4 border-b border-white/10 pb-2">Full Evidence Dossier</h3>
                        {loading ? (
                            <div className="space-y-4 animate-pulse">
                                <div className="h-4 bg-white/5 rounded w-3/4"></div>
                                <div className="h-4 bg-white/5 rounded w-1/2"></div>
                                <div className="h-64 bg-white/5 rounded"></div>
                            </div>
                        ) : dossier ? (
                            <div className="bg-bg-secondary/50 p-8 rounded-xl border border-white/5">
                                <ReactMarkdown>{dossier}</ReactMarkdown>
                            </div>
                        ) : (
                            <div className="text-text-muted italic border border-dashed border-white/20 p-8 rounded-xl text-center">
                                No detailed dossier available for this claim.
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Results;
