import React, { useEffect, useState } from 'react';
import {
    BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
    PieChart, Pie, Cell, Legend
} from 'recharts';
import { api } from '../services/api';

const COLORS = {
    supported: '#00dc82', // Bright Green
    contradicted: '#ef4444', // Bright Red
    undetermined: '#94a3b8' // Grey
};

const Dashboard = () => {
    const [stats, setStats] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        loadStats();
    }, []);

    const loadStats = async () => {
        try {
            const data = await api.getStats();
            setStats(data);
        } catch (error) {
            console.error("Failed to load stats", error);
        } finally {
            setLoading(false);
        }
    };

    if (loading) return <div className="p-12 text-center text-text-muted animate-pulse">Loading dashboard analytics...</div>;
    if (!stats) return <div className="p-12 text-center text-accent-error">Failed to load statistics. Is the backend running?</div>;

    // Prepare chart data
    const pieData = [
        { name: 'Supported', value: stats.supported },
        { name: 'Contradicted', value: stats.contradicted }
    ];

    const barData = Object.entries(stats.by_book || {}).map(([book, data]) => ({
        name: book.length > 25 ? book.substring(0, 25) + '...' : book,
        full: book,
        supported: data.supported,
        contradicted: data.contradicted
    }));

    return (
        <div className="dashboard-page fade-in pb-12">
            <header className="page-header">
                <h1 className="text-4xl font-black text-white mb-2 tracking-tight">Project Analytics</h1>
                <p className="text-secondary text-lg">Real-time verification pipeline statistics and insights</p>
            </header>

            {/* Metrics Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
                <MetricCard
                    label="Total Claims"
                    value={stats.total}
                    trend="+12%"
                    trendUp={true}
                />
                <MetricCard
                    label="Accuracy"
                    value={`${stats.accuracy || 0}%`}
                    sub="vs Ground Truth"
                />
                <MetricCard
                    label="Confidence"
                    value={`${(stats.avg_confidence * 100).toFixed(1)}%`}
                    sub="Average Score"
                />
                <MetricCard
                    label="Supported"
                    value={`${((stats.supported / stats.total) * 100).toFixed(1)}%`}
                    sub={`${stats.supported} / ${stats.total} Claims`}
                />
            </div>

            {/* Charts Row */}
            <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
                <div className="glass-panel p-8">
                    <h3 className="text-xl font-bold text-white mb-8 border-b border-white/5 pb-4">Verdict Distribution</h3>
                    <div className="h-80">
                        <ResponsiveContainer width="100%" height="100%">
                            <PieChart>
                                <Pie
                                    data={pieData}
                                    cx="50%"
                                    cy="50%"
                                    innerRadius={80}
                                    outerRadius={100}
                                    paddingAngle={5}
                                    dataKey="value"
                                    stroke="none"
                                >
                                    {pieData.map((entry, index) => (
                                        <Cell key={`cell-${index}`} fill={Object.values(COLORS)[index]} />
                                    ))}
                                </Pie>
                                <Tooltip
                                    contentStyle={{ backgroundColor: '#121217', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '12px' }}
                                    itemStyle={{ color: '#fff' }}
                                />
                                <Legend iconType="circle" />
                            </PieChart>
                        </ResponsiveContainer>
                    </div>
                </div>

                <div className="glass-panel p-8">
                    <h3 className="text-xl font-bold text-white mb-8 border-b border-white/5 pb-4">Analysis by Book</h3>
                    <div className="h-80">
                        <ResponsiveContainer width="100%" height="100%">
                            <BarChart data={barData} layout="vertical" barSize={12} barGap={4}>
                                <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.2} horizontal={true} vertical={false} />
                                <XAxis type="number" stroke="#94a3b8" fontSize={12} tickLine={false} axisLine={false} />
                                <YAxis dataKey="name" type="category" width={150} stroke="#94a3b8" fontSize={12} tickLine={false} axisLine={false} />
                                <Tooltip
                                    contentStyle={{ backgroundColor: '#121217', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '12px' }}
                                    cursor={{ fill: 'rgba(255,255,255,0.03)' }}
                                />
                                <Bar dataKey="supported" stackId="a" fill={COLORS.supported} radius={[0, 4, 4, 0]} />
                                <Bar dataKey="contradicted" stackId="a" fill={COLORS.contradicted} radius={[0, 4, 4, 0]} />
                            </BarChart>
                        </ResponsiveContainer>
                    </div>
                </div>
            </div>
        </div>
    );
};

// Sub-component for metric cards
const MetricCard = ({ label, value, sub, trend, trendUp }) => (
    <div className="metric-card glass-panel p-6 flex flex-col justify-between h-32 hover:translate-y-[-4px] transition-transform">
        <div className="flex justify-between items-start">
            <span className="text-text-secondary text-xs font-bold uppercase tracking-widest">{label}</span>
            {trend && (
                <span className={`text-xs font-bold px-2 py-1 rounded-full ${trendUp ? 'bg-green-500/10 text-accent-success' : 'bg-red-500/10 text-accent-error'}`}>
                    {trend}
                </span>
            )}
        </div>
        <div>
            <div className="text-4xl font-black text-white tracking-tight">{value}</div>
            {sub && <div className="text-text-muted text-sm mt-1 font-medium">{sub}</div>}
        </div>
    </div>
);

export default Dashboard;
