import React, { useState, useEffect, useRef } from 'react';
import { Play, Square, RefreshCw, Terminal, CheckCircle, Clock } from 'lucide-react';
import { api } from '../services/api';

const STAGES = [
    'Starting', 'Ingestion', 'Embedding', 'Claims', 'Retrieval', 'Reasoning', 'Results'
];

const Pipeline = () => {
    const [status, setStatus] = useState(null);
    const [loading, setLoading] = useState(false);
    const logEndRef = useRef(null);

    // Poll status every 2 seconds
    useEffect(() => {
        fetchStatus();
        const interval = setInterval(fetchStatus, 2000);
        return () => clearInterval(interval);
    }, []);

    // Auto-scroll logs
    useEffect(() => {
        logEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [status?.log]);

    const fetchStatus = async () => {
        try {
            const data = await api.getPipelineStatus();
            setStatus(data);
        } catch (err) {
            console.error(err);
        }
    };

    const handleStart = async () => {
        setLoading(true);
        try {
            await api.startPipeline(true);
            fetchStatus();
        } catch (err) {
            alert('Failed to start pipeline');
        } finally {
            setLoading(false);
        }
    };

    const handleStop = async () => {
        if (!window.confirm('Are you sure you want to stop the pipeline?')) return;
        try {
            await api.stopPipeline();
            fetchStatus();
        } catch (err) {
            alert('Failed to stop pipeline');
        }
    };

    const handleReset = async () => {
        if (!window.confirm('Reset pipeline status?')) return;
        try {
            await api.resetPipeline();
            fetchStatus();
        } catch (err) {
            alert('Failed to reset pipeline');
        }
    };

    if (!status) return <div className="loading">Connecting to backend...</div>;

    const currentStageIndex = STAGES.indexOf(status.stage?.split(' ')[0] || '');
    const isRunning = status.running;

    return (
        <div className="pipeline-page fade-in">
            <header className="page-header mb-8 flex justify-between items-center">
                <div>
                    <h1 className="text-3xl font-bold text-white mb-2">Pipeline Control</h1>
                    <p className="text-secondary">Manage and monitor verification process</p>
                </div>

                <div className="actions flex gap-4">
                    {!isRunning ? (
                        <button
                            onClick={handleStart}
                            disabled={loading}
                            className="btn-primary"
                        >
                            <Play size={18} /> Run Pipeline
                        </button>
                    ) : (
                        <button
                            onClick={handleStop}
                            className="btn-secondary text-accent-error border-accent-error"
                        >
                            <Square size={18} /> Stop
                        </button>
                    )}
                    <button onClick={handleReset} className="btn-secondary">
                        <RefreshCw size={18} />
                    </button>
                </div>
            </header>

            {/* Progress Stepper */}
            <div className="glass-panel p-8 mb-8">
                <div className="flex justify-between relative">
                    {/* Connecting Line */}
                    <div className="absolute top-5 left-0 right-0 h-1 bg-gray-800 -z-0"></div>
                    <div
                        className="absolute top-5 left-0 h-1 bg-accent-primary transition-all duration-500"
                        style={{ width: `${(Math.max(0, currentStageIndex) / (STAGES.length - 1)) * 100}%` }}
                    ></div>

                    {STAGES.map((stage, index) => {
                        const isCompleted = index < currentStageIndex;
                        const isActive = index === currentStageIndex;

                        return (
                            <div key={stage} className="flex flex-col items-center z-10 relative">
                                <div
                                    className={`w-10 h-10 rounded-full flex items-center justify-center border-4 transition-all duration-300
                                ${isCompleted
                                            ? 'bg-accent-primary border-accent-primary text-white'
                                            : isActive
                                                ? 'bg-bg-card border-accent-primary text-accent-primary animate-pulse'
                                                : 'bg-bg-card border-gray-700 text-gray-500'
                                        }
                            `}
                                >
                                    {isCompleted ? <CheckCircle size={18} /> :
                                        isActive ? <RefreshCw size={18} className="animate-spin" /> :
                                            <Clock size={18} />}
                                </div>
                                <div className={`mt-3 text-sm font-medium transition-colors duration-300 ${isActive || isCompleted ? 'text-white' : 'text-gray-500'}`}>
                                    {stage}
                                </div>
                            </div>
                        );
                    })}
                </div>
            </div>

            {/* Console Output */}
            <div className="glass-panel p-0 overflow-hidden flex flex-col h-[500px]">
                <div className="bg-bg-secondary p-4 border-b border-border-color flex justify-between items-center">
                    <div className="flex items-center gap-2">
                        <Terminal size={18} className="text-text-secondary" />
                        <span className="font-mono text-sm">Live Logs</span>
                    </div>
                    {status.error && (
                        <span className="badge danger">Error: {status.error}</span>
                    )}
                </div>
                <div className="bg-[#0c0e12] p-4 font-mono text-sm overflow-y-auto flex-1 custom-scrollbar">
                    {status.log?.length === 0 && (
                        <div className="text-text-muted italic opacity-50">Waiting for logs...</div>
                    )}
                    {status.log?.map((line, i) => (
                        <div key={i} className="mb-1 break-words opacity-90 hover:opacity-100">
                            <span className="text-text-muted select-none mr-3">
                                {String(i + 1).padStart(3, '0')}
                            </span>
                            <span
                                className={
                                    line.includes('ERROR') ? 'text-accent-error' :
                                        line.includes('INFO') ? 'text-accent-primary' :
                                            'text-text-primary'
                                }
                            >
                                {line}
                            </span>
                        </div>
                    ))}
                    <div ref={logEndRef} />
                </div>
            </div>
        </div>
    );
};

export default Pipeline;
