import React from 'react';
import { NavLink } from 'react-router-dom';
import {
  LayoutDashboard,
  FileText,
  Activity,
  BookOpen,
  GitGraph,
  Cpu
} from 'lucide-react';

const Sidebar = () => {
  const navItems = [
    { icon: <LayoutDashboard size={20} />, label: 'Dashboard', path: '/' },
    { icon: <GitGraph size={20} />, label: 'Pipeline Control', path: '/pipeline' },
    { icon: <FileText size={20} />, label: 'Claim Results', path: '/results' },
    { icon: <BookOpen size={20} />, label: 'Documentation', path: '/docs' },
  ];

  return (
    <aside className="sidebar fixed left-4 top-4 bottom-4 w-72 glass-panel z-50 flex flex-col p-6 border-r-0">
      <div className="mb-10 px-2">
        <h1 className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-accent-primary to-accent-secondary mb-1 tracking-tight">
          NovelVerified.AI
        </h1>
        <div className="flex items-center gap-2 text-text-muted">
          <Cpu size={12} />
          <span className="text-xs font-mono uppercase tracking-widest">System v1.2</span>
        </div>
      </div>

      <nav className="flex flex-col gap-2 flex-1">
        {navItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            className={({ isActive }) =>
              `flex items-center gap-3 px-4 py-3.5 rounded-xl text-sm font-semibold transition-all duration-200 group relative overflow-hidden ${isActive
                ? 'bg-accent-primary text-white shadow-lg shadow-blue-500/25'
                : 'text-text-secondary hover:text-white hover:bg-white/5'
              }`
            }
          >
            <span className="relative z-10">{item.icon}</span>
            <span className="relative z-10">{item.label}</span>
          </NavLink>
        ))}
      </nav>

      <div className="pt-6 border-t border-white/5 px-2">
        <div className="flex items-center gap-3">
          <span className="relative flex h-2.5 w-2.5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-accent-success opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-accent-success"></span>
          </span>
          <span className="text-xs font-bold text-text-muted uppercase tracking-wider">System Online</span>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
