import React from 'react';
import { Outlet } from 'react-router-dom';
import Sidebar from './Sidebar';

const Layout = () => {
  return (
    <div className="app-layout min-h-screen bg-bg-primary text-text-primary selection:bg-accent-primary selection:text-white">
      <Sidebar />
      <main className="pl-80 pr-8 py-8 w-full max-w-[1920px] mx-auto min-h-screen relative">
        <Outlet />
      </main>
    </div>
  );
};

export default Layout;
