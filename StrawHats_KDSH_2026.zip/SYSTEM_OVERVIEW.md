# NovelVerified.AI - System Overview

## KDSH 2026 Track A Submission

**Team:** StrawHats  
**Repository:** https://github.com/bhagyeshmagar/StrawHats_KDSH_2026

---

## 🎯 The Problem

**Task:** Given a full novel (100k+ words) and a character's hypothetical backstory, determine if the backstory is:
- **CONSISTENT (1)** - Backstory aligns with novel events
- **CONTRADICTED (0)** - Backstory conflicts with novel events

---

## 🏗️ System Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                              INPUT DATA                                      │
│                                                                              │
│   📚 Novel Text (.txt)              📋 Claims (CSV)                         │
│   └─ Full novel, 100k+ words        └─ id, book_name, character, content    │
└────────────────────────────────────────┬────────────────────────────────────┘
                                         │
                                         ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                         STAGE 1: INGESTION                                   │
│                         (agents/ingestion_agent.py)                          │
│                                                                              │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │ PATHWAY DOCUMENT STORE (Track A Requirement)                         │   │
│   │                                                                      │   │
│   │ • Chunks novel into 1400-token segments                             │   │
│   │ • 300-token overlap between chunks                                  │   │
│   │ • Labels each chunk with TEMPORAL SLICE:                            │   │
│   │   - EARLY (0-30%): Character introductions, world-building          │   │
│   │   - MID (30-70%): Main plot events                                  │   │
│   │   - LATE (70-100%): Resolutions, revelations                        │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│   Output: pathway_store/chunks.jsonl                                         │
└────────────────────────────────────────┬────────────────────────────────────┘
                                         │
                                         ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                         STAGE 2: EMBEDDING                                   │
│                         (agents/embedding_agent.py)                          │
│                                                                              │
│   • Model: all-MiniLM-L6-v2 (384-dimensional vectors)                       │
│   • Creates embeddings for each chunk                                        │
│   • Builds FAISS index for similarity search                                 │
│                                                                              │
│   Output: index/faiss.index, index/meta.pkl                                  │
└────────────────────────────────────────┬────────────────────────────────────┘
                                         │
                                         ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                         STAGE 3: CLAIM PARSING                               │
│                         (agents/claim_parser.py)                             │
│                                                                              │
│   • Reads train.csv and test.csv                                            │
│   • Extracts claims with: id, book_name, character, claim_text              │
│                                                                              │
│   Output: claims/claims.jsonl                                                │
└────────────────────────────────────────┬────────────────────────────────────┘
                                         │
                                         ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                         STAGE 4: RETRIEVAL                                   │
│                         (agents/retriever_agent.py)                          │
│                                                                              │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │ TEMPORAL-AWARE RETRIEVAL                                             │   │
│   │                                                                      │   │
│   │ For each claim:                                                      │   │
│   │ 1. Standard Query: "Character: claim text"                          │   │
│   │ 2. Counterfactual Query: "Character: negated claim" (ANTI-BIAS)     │   │
│   │                                                                      │   │
│   │ Retrieves top passages from EACH temporal slice:                    │   │
│   │ • 3 from EARLY section                                               │   │
│   │ • 3 from MID section                                                 │   │
│   │ • 3 from LATE section                                                │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│   Output: evidence/{claim_id}.json                                           │
└────────────────────────────────────────┬────────────────────────────────────┘
                                         │
                                         ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                         STAGE 5: REASONING                                   │
│                         (agents/reasoning_agent.py)                          │
│                                                                              │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │ 4-STAGE ANTI-BIAS PIPELINE                                           │   │
│   │                                                                      │   │
│   │ STAGE A: DECOMPOSE                                                   │   │
│   │ └─ Break claim into atomic sub-claims                               │   │
│   │ └─ Classify: temporal, factual, psychological, capability           │   │
│   │                                                                      │   │
│   │ STAGE B: SEEK SUPPORT                                                │   │
│   │ └─ Prompt: "Find evidence this claim is TRUE"                       │   │
│   │ └─ Output: support_confidence (0.0-1.0)                             │   │
│   │                                                                      │   │
│   │ STAGE C: SEEK CONTRADICTION                                          │   │
│   │ └─ Prompt: "Find evidence this claim is FALSE"                      │   │
│   │ └─ Output: contradiction_confidence (0.0-1.0)                       │   │
│   │                                                                      │   │
│   │ STAGE D: SYNTHESIZE                                                  │   │
│   │ └─ Apply calibrated thresholds:                                     │   │
│   │    • contradiction > 0.4 → CONTRADICTED                             │   │
│   │    • support > 0.7 AND contradiction < 0.25 → SUPPORTED             │   │
│   │    • Otherwise → UNDETERMINED                                        │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│   Output: verdicts/{claim_id}.json                                           │
└────────────────────────────────────────┬────────────────────────────────────┘
                                         │
                                         ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                         STAGE 6: DOSSIER GENERATION                          │
│                         (agents/dossier_writer.py)                           │
│                                                                              │
│   Creates structured Markdown reports with:                                  │
│   • Sub-claims decomposition table                                          │
│   • Temporal evidence organization (EARLY/MID/LATE)                         │
│   • Dual-perspective scores                                                  │
│   • Constraint violation analysis                                            │
│                                                                              │
│   Output: dossiers/{claim_id}.md                                             │
└────────────────────────────────────────┬────────────────────────────────────┘
                                         │
                                         ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                         STAGE 7: RESULTS AGGREGATION                         │
│                         (agents/results_aggregator.py)                       │
│                                                                              │
│   • Collects all verdicts                                                   │
│   • Maps: supported→1, contradicted→0, undetermined→0                      │
│   • Generates KDSH-compliant CSV                                            │
│                                                                              │
│   Output: output/results.csv                                                 │
└────────────────────────────────────────┬────────────────────────────────────┘
                                         │
                                         ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                              FINAL OUTPUT                                    │
│                                                                              │
│   results.csv:                                                               │
│   ┌─────────────────────────────────────────────────────────────────────┐   │
│   │ Story ID,Prediction,Rationale                                        │   │
│   │ 95,1,Evidence supports claim about character's early life.          │   │
│   │ 136,0,Temporal constraint violated: knew before meeting.            │   │
│   │ ...                                                                  │   │
│   └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 🔑 Key Features for Track A Compliance

| Feature | Description | Why It Matters |
|---------|-------------|----------------|
| **Pathway Store** | Chunks stored via Pathway framework | Track A requirement - not just file I/O |
| **Temporal Slicing** | Evidence from EARLY/MID/LATE sections | Detects timeline inconsistencies |
| **Dual-Perspective** | Seeks BOTH support AND contradiction | Prevents "all supported" bias |
| **Anti-Bias Thresholds** | Calibrated confidence levels | Honest uncertainty handling |
| **Constraint Types** | Temporal, capability, psychological | Structured reasoning |
| **Counterfactual Queries** | Negated claim searches | Actively finds contradictions |

---

## 📂 File Structure

```
StrawHats_KDSH_2026/
├── agents/
│   ├── ingestion_agent.py      # Pathway-based chunking
│   ├── pathway_store.py        # Pathway document store
│   ├── embedding_agent.py      # FAISS index creation
│   ├── claim_parser.py         # CSV parsing
│   ├── retriever_agent.py      # Temporal retrieval
│   ├── reasoning_agent.py      # 4-stage reasoning (Claude)
│   ├── reasoning_agent_local.py # 4-stage reasoning (Ollama)
│   ├── constraint_types.py     # Data structures
│   ├── dossier_writer.py       # Markdown reports
│   └── results_aggregator.py   # Final CSV
├── data/
│   ├── novels/                 # Novel .txt files
│   ├── train.csv               # Training claims
│   └── test.csv                # Test claims
├── run_all.py                  # Pipeline orchestrator
├── TRACK_A_JUSTIFICATION.md    # Report content
└── tests/
    └── test_integration.py     # Integration tests
```

---

## 🚀 How to Run

```bash
# Full pipeline with local LLM (Ollama)
python3 run_all.py --clean --local

# Full pipeline with Claude API
python3 run_all.py --clean

# Run integration tests
pytest tests/test_integration.py -v

# Create submission package
python3 create_submission.py
```

---

## 📊 Anti-Bias Mechanism

The system actively prevents "supported" bias:

```
              ┌─────────────────────┐
              │   CLAIM INPUT       │
              └──────────┬──────────┘
                         │
         ┌───────────────┼───────────────┐
         ▼               ▼               ▼
    ┌─────────┐    ┌──────────┐    ┌─────────┐
    │ SUPPORT │    │CONTRADICT│    │ COMPARE │
    │ PROMPT  │    │ PROMPT   │    │ SCORES  │
    └────┬────┘    └────┬─────┘    └────┬────┘
         │              │               │
         ▼              ▼               ▼
    support=0.6    contradict=0.3   ┌───────────────────┐
                                    │ THRESHOLDS:       │
                                    │ • contradict>0.4  │
                                    │   → CONTRADICTED  │
                                    │ • support>0.7 AND │
                                    │   contradict<0.25 │
                                    │   → SUPPORTED     │
                                    │ • else            │
                                    │   → UNDETERMINED  │
                                    └───────────────────┘
```

---

## 📝 Team StrawHats - KDSH 2026
