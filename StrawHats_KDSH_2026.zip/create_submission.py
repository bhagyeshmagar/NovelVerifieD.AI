import zipfile
import os

def make_zip(source_dir, output_filename):
    if os.path.exists(output_filename):
        os.remove(output_filename)

    with zipfile.ZipFile(output_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(source_dir):
            dirs[:] = [d for d in dirs if not d.startswith('.') and d not in ['node_modules', 'dist', '__pycache__', 'pro_artifacts', 'chunks', 'index', 'claims', 'evidence', 'verdicts', 'dossiers', 'pathway_store', 'wandb']]
            for file in files:
                if file.startswith('.') or file.endswith('.pyc') or file == output_filename:
                    continue
                file_path = os.path.join(root, file)
                arcname = os.path.relpath(file_path, source_dir)
                zipf.write(file_path, arcname)
                print(f"Adding {arcname}")

if __name__ == "__main__":
    make_zip('.', 'StrawHats_KDSH_2026.zip')
    print("Submission ZIP created successfully!")
